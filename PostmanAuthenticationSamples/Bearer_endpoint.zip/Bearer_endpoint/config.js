module.exports = {
    secret: 'asc_test_token_secret'
};